import React from "react";
import Container from "react-bootstrap/Container";
import SearchInput from "./searchinput";

export class App extends React.Component {
  render() {
    return (
      <Container className="p-3">
        <SearchInput />
      </Container>
    );
  }
}

export default App;
