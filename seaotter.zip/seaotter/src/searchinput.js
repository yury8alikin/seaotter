import React from "react";
import ButtonGroup from "react-bootstrap/ButtonGroup";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import Spinner from "react-bootstrap/Spinner";
import Alert from "react-bootstrap/Alert";
import PrintResults from "./printresults";
import { connect } from "react-redux";
import { activate, close } from "./actions";

export class SearchInput extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      searchQuery: "",
      searchLanguage: "JavaScript",
      isLoading: false,
      searchResults: [],
      searchTotalCounts: 0,
      isApiFail: false,
      apiFailMessage: "",
      prevLastResultsIndex: 0,
    };
  }
  handleSubmit = (e, next = false) => {
    e.preventDefault();
    this.setState({
      isLoading: true,
      isApiFail: false,
      prevLastResultsIndex: next
        ? this.state.prevLastResultsIndex + this.state.searchResults.length
        : 0,
      searchResults: [],
    });
    const page = next ? (this.props.data.page || 1) + 1 : 1;
    this.props.activate({ page });
    if (this.state.searchQuery) {
      fetch(
        `https://api.github.com/search/repositories?q=language:${this.state.searchLanguage}+${this.state.searchQuery}+in:description&page=${page}`
      )
        .then((r) => {
          if (r.status > 199 && r.status < 300) return r.json();
          else {
            r.json().then((r) =>
              this.setState({
                apiFailMessage: r.message || "API Response Failure",
              })
            );
            throw Error("API Failure");
          }
        })
        .then((r) => {
          this.setState({
            searchResults: r.items,
            searchTotalCounts: r.total_count,
            isLoading: false,
          });
        })
        .catch((e) => {
          this.setState({
            isApiFail: true,
            searchTotalCounts: 0,
            prevLastResultsIndex: 0,
            isLoading: false,
          });
        });
    }
  };
  nextBtn = (e, next = false) => this.handleSubmit(e, next);
  render() {
    return (
      <>
        {this.state.isApiFail}
        {this.state.isApiFail ? (
          <Alert key="0" variant="danger">
            {this.state.apiFailMessage}
          </Alert>
        ) : null}
        <Form
          onSubmit={(e) => {
            this.handleSubmit(e);
          }}
        >
          <Form.Group controlId="form.Query">
            <Form.Label>Search:</Form.Label>
            <Form.Control
              type="text"
              maxLength="256"
              placeholder="Looking on GitHub for..."
              name="searchQuery"
              value={this.state.searchQuery}
              onChange={(e) => this.setState({ searchQuery: e.target.value })}
            />
          </Form.Group>
          <Form.Group controlId="form.Languge">
            <Form.Label>Language select</Form.Label>
            <Form.Control
              as="select"
              value={this.state.searchLanguage}
              onChange={(e) =>
                this.setState({ searchLanguage: e.target.value })
              }
            >
              <option>JavaScript</option>
              <option>TypeScript</option>
              <option>Java</option>
              <option>Python</option>
              <option>C++</option>
            </Form.Control>
          </Form.Group>
          <ButtonGroup>
            <Button
              variant="primary"
              type="submit"
              loading="true"
              disabled={this.state.isLoading || !this.state.searchQuery.length}
            >
              {this.state.isLoading ? (
                <>
                  <Spinner
                    as="span"
                    animation="border"
                    size="sm"
                    role="status"
                    aria-hidden="true"
                  />
                  <span className="sr-only">Loading...</span>
                </>
              ) : (
                "Find"
              )}
            </Button>
            {this.state.prevLastResultsIndex < this.state.searchTotalCounts ? (
              <Button
                variant={this.state.isLoading ? "secondary" : "info"}
                disabled={this.state.isLoading}
                onClick={(e) => {
                  this.nextBtn(e, true);
                }}
              >
                More results
              </Button>
            ) : null}
          </ButtonGroup>
          {this.state.searchTotalCounts ? (
            <p>{this.state.searchTotalCounts} Search results</p>
          ) : null}
        </Form>
        <br />
        <br />
        <PrintResults
          printlist={this.state.searchResults}
          startIndex={this.state.prevLastResultsIndex}
        />
      </>
    );
  }
}

const mapStateToProps = (state) => ({
  data: state.data,
});

const mapDispatchToProps = {
  activate,
  close,
};

const SearchInputContainer = connect(
  mapStateToProps,
  mapDispatchToProps
)(SearchInput);

export default SearchInputContainer;
