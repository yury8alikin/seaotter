import { combineReducers } from "redux";
export const data = (state = {}, action) => {
  switch (action.type) {
    case "ACTIVATE":
      return action.data;
    case "CLOSE":
      return {};
    default:
      return state;
  }
};

export const reducers = combineReducers({
  data,
});
