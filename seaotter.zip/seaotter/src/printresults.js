import React from "react";
import Table from "react-bootstrap/Table";

export class PrintResults extends React.Component {
  render() {
    if (this.props.printlist && this.props.printlist.length)
      return (
        <Table striped bordered hover size="sm">
          <thead>
            <tr>
              <th>#</th>
              <th>Id</th>
              <th>Language</th>
              <th>Name</th>
              <th>Details</th>
            </tr>
          </thead>
          <tbody>
            {this.props.printlist.map((query, index) => (
              <tr key={query.id}>
                <td>{this.props.startIndex + index + 1}</td>
                <td>{query.id}</td>
                <td>{query.language}</td>
                <td>{query.name}</td>
                <td>{query.description}</td>
              </tr>
            ))}
          </tbody>
        </Table>
      );
    else return null;
  }
}

export default PrintResults;
