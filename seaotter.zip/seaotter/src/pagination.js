import React from "react";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Button from "react-bootstrap/Button";

export class Pagination extends React.Component {
  render() {
    if (this.props.list && this.props.list.length)
      return (
        <Container>
          <Row>
            <Col>
              <Button variant="link">1</Button>
            </Col>
          </Row>
        </Container>
      );
    else return null;
  }
}

export default Pagination;
