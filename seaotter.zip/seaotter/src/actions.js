export const activate = (data) => ({
  type: "ACTIVATE",
  data,
});

export const close = () => ({
  type: "CLOSE",
});
